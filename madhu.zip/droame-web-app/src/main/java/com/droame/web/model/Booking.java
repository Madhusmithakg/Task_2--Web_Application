package com.droame.web.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name="Booking")
public class Booking {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long booking_id;
	@Column(name="location")
	private String location;
	@Column(name="Drone_shot_name")
	private String Drone_shot_name;
	

	@JsonFormat(pattern="yyyy-MM-dd", shape=Shape.STRING)
	@Column(name="date")
	private String date;
	
	@ManyToOne(targetEntity = Customer.class)
    @JoinColumn(name = "customer_id")
    private Customer customerId;
	public long getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(long booking_id) {
		this.booking_id = booking_id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDrone_shot_name() {
		return Drone_shot_name;
	}
	public void setDrone_shot_name(String drone_shot_name) {
		Drone_shot_name = drone_shot_name;
	}
	
	
	
	
	public Customer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date= date;
	}
	
}
