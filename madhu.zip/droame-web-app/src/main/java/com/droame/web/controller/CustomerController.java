  package com.droame.web.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.droame.web.model.Customer;

import com.droame.web.service.Customerservice;

@Controller
public class CustomerController {
	
	@Autowired
	private Customerservice customerservice;
	// display list of customers
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("listCustomers",customerservice.getAllCustomers());
		return "index";
	}
	
	
	
	@GetMapping("/shownewCustomerForm")
	public String shownewCustomerForm(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer", customer);
		return "new_customer";
	}
	
	
	 @PostMapping("/saveCustomer")
	 public String saveCustomer(@ModelAttribute("customer") Customer customer) {
	     // save customer to database
		 customerservice.saveCustomer(customer);
	     return "redirect:/";
	 }
	 
	 
	 
	 @GetMapping("/showFormForUpdate/{id}")
	 public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
	  
	  // get customer from the service
	  Customer customer = customerservice.getCustomerById(id);
	  
	  // set customer as a model attribute to pre-populate the form
	  model.addAttribute("customer", customer);
	  return "update_customer";
	 }
	 
	 @GetMapping("/deleteCustomer/{id}")
	 public String deleteCustomer(@PathVariable (value = "id") long id) {
	  
	  // call delete customer method 
	  this.customerservice.deleteCustomerById(id);
	  return "redirect:/";
	 }
	
	
	
}