package com.droame.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.droame.web.model.Booking;

import com.droame.web.repository.BookingRepository;
@Service
public class BookingServiceImpl implements BookingService{

	@Autowired
	
	private BookingRepository bookingRepository;
	@Override
	public List<Booking> getAllBookings() {
		return bookingRepository.findAll();
	}
	@Override
	public void saveBooking(Booking booking) {
		this.bookingRepository.save(booking);
		
	}
	@Override
	public Booking getBookingById(long booking_id) {
		Optional < Booking > optional = bookingRepository.findById(booking_id);
	    Booking booking = null;
	    if (optional.isPresent()) {
	    	booking = optional.get();
	    } else {
	        throw new RuntimeException(" Booking not found for id :: " + booking_id);
	    }
	    return booking;
	}
	
	@Override
	public void deleteBookingById(long booking_id) {
		this.bookingRepository.deleteById(booking_id);
	}

	
}
