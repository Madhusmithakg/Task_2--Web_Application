package com.droame.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication

public class DroameWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DroameWebAppApplication.class, args);
	}

}
  