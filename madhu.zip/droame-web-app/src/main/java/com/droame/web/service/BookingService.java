package com.droame.web.service;

import java.util.List;

import com.droame.web.model.Booking;

public interface BookingService {

	
	List<Booking> getAllBookings();
	void saveBooking(Booking booking);
	Booking getBookingById(long booking_id);
	void deleteBookingById(long booking_id);
}
