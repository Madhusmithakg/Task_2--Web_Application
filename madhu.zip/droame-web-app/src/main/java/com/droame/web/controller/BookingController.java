package com.droame.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.droame.web.model.Booking;

import com.droame.web.service.BookingService;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;
	// display list of bookings
	@GetMapping("/booking")
	public String viewHomePage(Model model) {
		model.addAttribute("listBookings", bookingService.getAllBookings());
		return "booklist";
	}
	
	@GetMapping("/newBooking/{id}")
	public String newBooking(Model model) {
		Booking booking= new Booking();
		model.addAttribute("booking", booking);
		return "book";
	}
	
	@PostMapping("/saveBooking")
	public String saveBooking(@ModelAttribute("booking") Booking booking) {
		bookingService.saveBooking(booking);
		return "redirect:/booking";
	}
	
	@GetMapping("/showBookingForUpdate/{id}")
	 public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		  
		  // get customer from the service
		  Booking booking = bookingService.getBookingById(id);
		  
		  // set customer as a model attribute to pre-populate the form
		  model.addAttribute("booking", booking);
		  return "update_book";	
	}
	
	 @GetMapping("/deleteBooking/{id}")
	 public String deleteBooking(@PathVariable (value = "id") long id) {
	  
	  // call delete customer method 
	  this.bookingService.deleteBookingById(id);
	  return "redirect:/booking";
	 }
}
