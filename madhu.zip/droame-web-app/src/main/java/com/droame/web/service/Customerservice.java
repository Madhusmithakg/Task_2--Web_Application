package com.droame.web.service;

import java.util.List;

import com.droame.web.model.Customer;

public interface Customerservice {
	List<Customer> getAllCustomers();
	
	void saveCustomer(Customer customer);
	Customer getCustomerById(long id);
	 void deleteCustomerById(long id);
	 
	

}
